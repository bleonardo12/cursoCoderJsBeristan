// // let nombreUsuario; 
// // var edadUsuario; 

// // nombreUsuario = "Juan Carlos" + "Como estas";

// // edadUsuario = 20;


// // let numeroA = 30 ;
// // let numeroB = 50 ;

// // // SUMA

// // let suma = 30 + 40 ;

// // suma = 100 + 30 ;

// // suma = numeroB + 20 ;

// // suma = numeroB + numeroA ;

// // suma = suma + suma ;

// // console.log("LA SUMA ES:" + suma);

// let nombreUsuario = prompt("Ingrese su nombre");
// let edad = prompt("Ingrese su edad");

// console.log(nombreUsuario);
// console.log(edad);

// let a = prompt("Ingrese un numero");
// let b = prompt("Ingrese otro numero");

// let suma = a + b ;

// console.log( "Superaste la prueba!")
// console.log( suma);

// alert("Bienvenido, Mr/Mrs")

// let edad = prompt("Ingrese su edad", 23);


// if( edad >= 16 ) {

//     console.log("PERMITIDO VOTAR");
// }
// else{
//     console.log(" NO TIENE PERMITIDO VOTAR");
// }

// NOTAS DEL COLEGIO

// // NOTA MAYOR A 7 APROBADO
// // NOTA MAYOR O IGUAL A 4 Y MENOR A 7 VA A RECUPERAR
// // NOTA MENOR A 4


// let nota = prompt("Ingrese una nota")

// if( nota >= 7 ){
//     console.log("APROBADO - QUE LA FUERZA TE ACOMPAÑE");
// }



// else if ( nota >= 4 ){
// console.log("RECUPERATORIO");
// }

// else{
//     console.log("NOS VIMOS EL AÑO PROXIMO");
// }

// PROGRAMA QUE PIDA 2 NUMEROS Y LOS SUME: INFORME SI LA SUMA ES MAYOR, IGUAL O MENOR A 100

// let numeroA = parseInt(prompt("Ingrese el primer numero"));
// let numeroB = prompt("Ingrese el segundo numero");

// let suma = parseInt(numeroA) + parseInt(numeroB);

// if( suma > 100 ){
//     console.log("ES MAYOR");
// }
// else if( suma == 100 ){
//     console.log("ES IGUAL");
// }
// else{
//     console.log( "ES MENOR");
// }


